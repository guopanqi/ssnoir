;; 研究配置；行为定义只在 scripts/research/分段兑现.scm。
(define 研究名称 "分段兑现")
(define 目标上限 18)
(define 回合上限 3)
(define 递增兑现 1)
(define 储备衰减 0)
(load-file "scripts/research/分段兑现.scm")
